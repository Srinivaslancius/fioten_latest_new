Austria;Vienna;83859;8075
Belgium;Brussels;30518;10192
Denmark;Copenhagen;43094;5295
Finland;Helsinki;304529;5147
France;Paris;543965;58728
Germany;Berlin;357022;82057
Greece;Athens;131625;10511
Ireland;Dublin;70723;3694
Italy;Roma;301316;57563
Luxembourg;Luxembourg;2586;424
Netherlands;Amsterdam;41526;15654
Portugal;Lisbon;91906;9957
Spain;Madrid;504790;39348
Sweden;Stockholm;410934;8839
United Kingdom;London;243820;58862